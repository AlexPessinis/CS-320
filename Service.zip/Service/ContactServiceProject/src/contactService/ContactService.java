package contactService;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
	private final Map<String, Contact> contacts = new HashMap<>();
	
	public void addContact(Contact contact) {
		if (contact == null) {
			throw new IllegalArgumentException("Contact cannot be null.");
		}
		String id = contact.getContactID();
		if (contacts.containsKey(id)) {
			throw new IllegalArgumentException("Contact must be unique.");
		}
		contacts.put(id, contact);
	}
	public void deleteContact(String contactID) {
		requireId(contactID);
		if (!contacts.containsKey(contactID)) {
			throw new IllegalArgumentException("Contact ID not found.");
		}
		contacts.remove(contactID);
		}
	public void updateFirstName(String contactID, String newFirstName) {
		Contact c = requireExisting(contactID);
		c.setFirstName(newFirstName);
	}
	public void updateLastName(String contactID, String newLastName) {
		Contact c = requireExisting(contactID);
		c.setLastName(newLastName);
	}
	public void updatePhone(String contactID, String newPhone) {
		Contact c = requireExisting(contactID);
		c.setPhone(newPhone);
	}
	public void updateAddress(String contactID, String newAddress) {
		Contact c = requireExisting(contactID);
		c.setAddress(newAddress);
	}
	public Contact getContact(String contactId) {
        requireId(contactId);
        return contacts.get(contactId);
    }

    public Map<String, Contact> getAllContacts() {
        return Collections.unmodifiableMap(contacts);
    }

    private void requireId(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Contact ID must be provided.");
        }
    }

    private Contact requireExisting(String id) {
        requireId(id);
        Contact c = contacts.get(id);
        if (c == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        return c;
    }

}
