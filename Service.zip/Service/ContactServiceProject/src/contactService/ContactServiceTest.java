package contactService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setup() {
        service = new ContactService();
    }

    @Test
    void addContactUniqueId() {
        Contact c1 = new Contact("ID1", "John", "Doe", "1234567890", "Addr1");
        Contact c2 = new Contact("ID2", "Jane", "Smith", "0987654321", "Addr2");

        service.addContact(c1);
        service.addContact(c2);

        assertEquals(c1, service.getContact("ID1"));
        assertEquals(c2, service.getContact("ID2"));

        Contact dup = new Contact("ID1", "Mike", "Lee", "1112223333", "Addr3");
        assertThrows(IllegalArgumentException.class, () -> service.addContact(dup));
    }

    @Test
    void deleteContactById() {
        Contact c = new Contact("DEL1", "John", "Doe", "1234567890", "Addr");
        service.addContact(c);

        service.deleteContact("DEL1");
        assertNull(service.getContact("DEL1"));

        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("DEL1"));
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact(null));
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact(""));
    }

    @Test
    void updateFieldsById() {
        Contact c = new Contact("UP1", "John", "Doe", "1234567890", "Addr");
        service.addContact(c);

        service.updateFirstName("UP1", "Jane");
        service.updateLastName("UP1", "Smith");
        service.updatePhone("UP1", "0987654321");
        service.updateAddress("UP1", "New Address");

        Contact updated = service.getContact("UP1");
        assertEquals("Jane", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("0987654321", updated.getPhone());
        assertEquals("New Address", updated.getAddress());
    }

    @Test
    void updateFailsForInvalidInputsOrMissingId() {
        Contact c = new Contact("UP2", "John", "Doe", "1234567890", "Addr");
        service.addContact(c);

        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("UP2", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("UP2", "LastNameTooLong"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("UP2", "12345"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("UP2",
                "This address string is way more than thirty chars long"));

        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("NOPE", "Ok"));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName(null, "Ok"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("", "1234567890"));
    }

    @Test
    void getAllContactsIsUnmodifiable() {
        Contact c = new Contact("X1", "John", "Doe", "1234567890", "Addr");
        service.addContact(c);

        var all = service.getAllContacts();
        assertTrue(all.containsKey("X1"));
        assertThrows(UnsupportedOperationException.class, () -> all.put("X2",
                new Contact("X2", "Jane", "Doe", "0987654321", "Addr2")));
    }
}