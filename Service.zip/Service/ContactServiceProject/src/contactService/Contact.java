package contactService;

import java.util.Objects;

/**
 * Name: Alexander Pessinis
 * Date: 11/16/2025
 * Contact.java
 * This class exists to provide basic local functions and variables for the
 * "Contact" object in my CS-320 assignment.
 */

public class Contact {
	
	//initializing all to private and using getters / setters
	private final String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	//constructor
	public Contact(String contactID, String firstName, String lastName, String phone, String address) {
	validateID(contactID);
	validateFirstName(firstName);
	validateLastName(lastName);
	validatePhone(phone);
	validateAddress(address);
		
	this.contactID = contactID;
	this.firstName = firstName;
	this.lastName = lastName;
	this.phone = phone;
	this.address = address;
	}
	
	@Override
	public boolean equals(Object x) {
		if (this == x) return true;
		if(!(x instanceof Contact)) return false;
		Contact contact = (Contact) x;
		return Objects.equals(contactID, contact.contactID);
	}
	@Override
	public int hashCode() {
		return Objects.hash(contactID);
	}
	
	//validation of values, private since it only needs to be accessed inside
	//the class
	private void validateID(String id) {
		if (id == null || id.length() > 10) {
			throw new IllegalArgumentException("Contact ID must be non-null and at most 10 characters.");
		}
	}
	private void validateFirstName(String fn) {
		if (fn == null || fn.length() > 10 ) {
			throw new IllegalArgumentException("First name must be non-null and at most 10 characters.");
		}
	}
	private void validateLastName(String ln) {
		if (ln == null || ln.length() > 10) {
			throw new IllegalArgumentException("Last name must be non-null and at most 10 characters.");
		}
	}
	private void validatePhone(String ph) {
		if (ph == null || ph.length() != 10 || !ph.chars().allMatch(Character::isDigit)) {
			throw new IllegalArgumentException("Phone must be non-null and exactly 10 digits.");
		}
	}
	private void validateAddress(String ad) {
		if (ad == null || ad.length() > 30) {
			throw new IllegalArgumentException("Address must be non-null and at most 30 characters.");
		}
	}
	
	
	//all my getters and setters are down here!
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		validateFirstName(firstName);
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		validateLastName(lastName);
		this.lastName = lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		validatePhone(phone);
		this.phone = phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		validateAddress(address);
		this.address = address;
	}
}
