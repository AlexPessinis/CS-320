package contactService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactTest {

    @Test
    void constructorValid() {
        Contact c = new Contact("ID123456", "John", "Doe", "1234567890", "123 Main St, Unit A");
        assertEquals("ID123456", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St, Unit A", c.getAddress());
    }

    @Test
    void constructorInvalidIdNullOrTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "John", "Doe", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("01234567890", "John", "Doe", "1234567890", "Addr")); // 11 chars
    }

    @Test
    void constructorInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", null, "Doe", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", "FirstnameTooLong", "Doe", "1234567890", "Addr"));
    }

    @Test
    void constructorInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", "John", null, "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () ->
   new Contact("ID", "John", "LastnameTooLong", "1234567890", "Addr"));
    }

    @Test
    void constructorInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", "John", "Doe", null, "Addr"));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", "John", "Doe", "12345", "Addr")); // too short
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", "John", "Doe", "12345678901", "Addr")); // too long
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", "John", "Doe", "12345678a0", "Addr")); // non-digit
    }

    @Test
    void constructorInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", "John", "Doe", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID", "John", "Doe", "1234567890",
                        "This address string is way more than thirty chars long"));
    }

    @Test
    void idIsImmutable() {
        Contact c = new Contact("ID", "John", "Doe", "1234567890", "Addr");
        assertEquals("ID", c.getContactId());
        // No setter; compilation ensures immutability
    }

    @Test
    void settersValidateProperly() {
        Contact c = new Contact("ID", "John", "Doe", "1234567890", "Addr");

        c.setFirstName("Jane");
        assertEquals("Jane", c.getFirstName());
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("NameTooLong!!"));

        c.setLastName("Smith");
        assertEquals("Smith", c.getLastName());
        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("LastNameTooLong"));

        c.setPhone("0987654321");
        assertEquals("0987654321", c.getPhone());
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("abcdefghij"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123456789"));

        c.setAddress("New Address");
        assertEquals("New Address", c.getAddress());
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
        assertThrows(IllegalArgumentException.class, () ->
                c.setAddress("This address string is way more than thirty chars long"));
    }
}