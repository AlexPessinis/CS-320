package AppointmentService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach
    void setup() {
        service = new AppointmentService();
    }

    @Test
    void addAppointmentUniqueId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment a1 = new Appointment("A1", futureDate, "Doctor visit");
        Appointment a2 = new Appointment("A2", futureDate, "Dentist visit");

        service.addAppointment(a1);
        service.addAppointment(a2);

        assertEquals(a1, service.getAppointment("A1"));
        assertEquals(a2, service.getAppointment("A2"));

        Appointment dup = new Appointment("A1", futureDate, "Therapy");
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(dup));
    }

    @Test
    void deleteAppointmentById() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment a = new Appointment("DEL1", futureDate, "Doctor visit");
        service.addAppointment(a);

        service.deleteAppointment("DEL1");
        assertNull(service.getAppointment("DEL1"));

        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("DEL1"));
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }

    @Test
    void getAllAppointmentsIsUnmodifiable() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment a = new Appointment("X1", futureDate, "Doctor visit");
        service.addAppointment(a);

        var all = service.getAllAppointments();
        assertTrue(all.containsKey("X1"));
        assertThrows(UnsupportedOperationException.class, () ->
                all.put("X2", new Appointment("X2", futureDate, "Dentist visit")));
    }
}
