package AppointmentService;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID must be unique.");
        }
        appointments.put(id, appointment);
    }

    public void deleteAppointment(String appointmentId) {
        requireId(appointmentId);
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        appointments.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        requireId(appointmentId);
        return appointments.get(appointmentId);
    }

    public Map<String, Appointment> getAllAppointments() {
        return Collections.unmodifiableMap(appointments);
    }

    private void requireId(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Appointment ID must be provided.");
        }
    }
}
