package AppointmentService;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    @Test
    void constructorValid() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // future
        Appointment a = new Appointment("A1", futureDate, "Doctor visit");
        assertEquals("A1", a.getAppointmentId());
        assertEquals(futureDate, a.getAppointmentDate());
        assertEquals("Doctor visit", a.getDescription());
    }

    @Test
    void invalidIdThrowsException() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("TOOLONGID123", futureDate, "Desc"));
    }

    @Test
    void invalidDateThrowsException() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", pastDate, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", null, "Desc"));
    }

    @Test
    void invalidDescriptionThrowsException() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", futureDate, null));
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", futureDate, "This description is way too long and exceeds fifty characters easily."));
    }

    @Test
    void settersWorkAndValidate() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment a = new Appointment("A1", futureDate, "Doctor visit");

        Date newFutureDate = new Date(System.currentTimeMillis() + 200000);
        a.setAppointmentDate(newFutureDate);
        assertEquals(newFutureDate, a.getAppointmentDate());
        assertThrows(IllegalArgumentException.class, () -> a.setAppointmentDate(new Date(System.currentTimeMillis() - 1000)));

        a.setDescription("Dentist visit");
        assertEquals("Dentist visit", a.getDescription());
        assertThrows(IllegalArgumentException.class, () -> a.setDescription(null));
    }
}

