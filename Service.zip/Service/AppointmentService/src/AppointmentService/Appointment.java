package AppointmentService;

import java.util.Date;
import java.util.Objects;

public class Appointment {

    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        validateId(appointmentId);
        validateDate(appointmentDate);
        validateDescription(description);

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        validateDate(appointmentDate);
        this.appointmentDate = appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    private void validateId(String id) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must be non-null and at most 10 characters.");
        }
    }

    private void validateDate(Date date) {
        if (date == null || date.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must be non-null and not in the past.");
        }
    }

    private void validateDescription(String desc) {
        if (desc == null || desc.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and at most 50 characters.");
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Appointment)) return false;
        Appointment that = (Appointment) o;
        return Objects.equals(appointmentId, that.appointmentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId);
    }
}

