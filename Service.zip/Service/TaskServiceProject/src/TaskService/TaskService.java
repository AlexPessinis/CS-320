package TaskService;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


public class TaskService {
	private final Map<String, Task> tasks = new HashMap<>();
	// program utility functions
	//-----------------------------------------------------------------------
	public void addTask(Task tsk) {
		if (tsk == null) {
			throw new IllegalArgumentException("Task cannot be null.");
		}
			String id = tsk.getTaskId();
	        if (tasks.containsKey(id)) {
	            throw new IllegalArgumentException("Task ID must be unique.");
	        }
	        tasks.put(id, tsk);
	}
	
    public void deleteTask(String taskId) {
        requireId(taskId);
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        tasks.remove(taskId);
    }
    
    public void updateName(String taskId, String newName) {
        Task t = requireExisting(taskId);
        t.setName(newName);
    }

    public void updateDescription(String taskId, String newDescription) {
        Task t = requireExisting(taskId);
        t.setDescription(newDescription);
    }

    public Task getTask(String taskId) {
        requireId(taskId);
        return tasks.get(taskId);
    }
    
    public Map<String, Task> getAllTasks() {
        return Collections.unmodifiableMap(tasks);
    }

    // local helper functions
    //-----------------------------------------------------------------------
    private void requireId(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Task ID must be provided.");
        }
    }

    private Task requireExisting(String id) {
        requireId(id);
        Task t = tasks.get(id);
        if (t == null) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        return t;
    }


}
