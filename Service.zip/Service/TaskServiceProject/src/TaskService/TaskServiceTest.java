package TaskService;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setup() {
        service = new TaskService();
    }

    @Test
    void addTaskUniqueId() {
        Task t1 = new Task("T1", "Homework", "Do math");
        Task t2 = new Task("T2", "Science", "Read chapter");

        service.addTask(t1);
        service.addTask(t2);

        assertEquals(t1, service.getTask("T1"));
        assertEquals(t2, service.getTask("T2"));

        Task dup = new Task("T1", "English", "Essay");
        assertThrows(IllegalArgumentException.class, () -> service.addTask(dup));
    }

    @Test
    void deleteTaskById() {
        Task t = new Task("DEL1", "Homework", "Do math");
        service.addTask(t);

        service.deleteTask("DEL1");
        assertNull(service.getTask("DEL1"));

        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("DEL1"));
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask(null));
    }

    @Test
    void updateFieldsById() {
        Task t = new Task("UP1", "Homework", "Do math");
        service.addTask(t);

        service.updateName("UP1", "Science");
        service.updateDescription("UP1", "Read chapter 5");

        Task updated = service.getTask("UP1");
        assertEquals("Science", updated.getName());
        assertEquals("Read chapter 5", updated.getDescription());
    }

    @Test
    void updateFailsForInvalidInputsOrMissingId() {
        Task t = new Task("UP2", "Homework", "Do math");
        service.addTask(t);

        assertThrows(IllegalArgumentException.class, () -> service.updateName("UP2", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("UP2",
                "This description is way too long and exceeds the fifty character limit easily."));
        assertThrows(IllegalArgumentException.class, () -> service.updateName("NOPE", "Ok"));
    }

    @Test
    void getAllTasksIsUnmodifiable() {
        Task t = new Task("X1", "Homework", "Do math");
        service.addTask(t);

        var all = service.getAllTasks();
        assertTrue(all.containsKey("X1"));
        assertThrows(UnsupportedOperationException.class, () ->
                all.put("X2", new Task("X2", "Science", "Desc")));
    }
}

