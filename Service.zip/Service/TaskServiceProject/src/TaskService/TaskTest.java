package TaskService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    void constructorValid() {
        Task t = new Task("T123", "Homework", "Finish math exercises");
        assertEquals("T123", t.getTaskId());
        assertEquals("Homework", t.getName());
        assertEquals("Finish math exercises", t.getDescription());
    }

    @Test
    void invalidIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task(null, "Homework", "Desc"));
        assertThrows(IllegalArgumentException.class, () ->
                new Task("TOOLONGTASKID", "Homework", "Desc"));
    }

    @Test
    void invalidNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", "ThisNameIsWayTooLongForTheLimit", "Desc"));
    }

    @Test
    void invalidDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", "Homework", null));
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", "Homework",
                        "This description is way too long and exceeds the fifty character limit easily."));
    }

    @Test
    void settersWorkAndValidate() {
        Task t = new Task("T1", "Homework", "Do math");
        t.setName("Science");
        assertEquals("Science", t.getName());
        assertThrows(IllegalArgumentException.class, () -> t.setName(null));

        t.setDescription("Read chapter 5");
        assertEquals("Read chapter 5", t.getDescription());
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(null));
    }

    @Test
    void idIsImmutable() {
        Task t = new Task("T1", "Homework", "Do math");
        assertEquals("T1", t.getTaskId());
    }
}
