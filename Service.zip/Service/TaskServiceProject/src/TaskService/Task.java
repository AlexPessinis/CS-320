package TaskService;

import java.util.Objects;

public class Task {
	// local variables
	//-----------------------------------------------------------------------
    private final String taskId;
    private String name;
    private String description;
	
	// constructor
	//-----------------------------------------------------------------------
	public Task(String taskID, String name, String description) {
        validateId(taskID);
        validateName(name);
        validateDescription(description);

        this.taskId = taskID;
        this.name = name;
        this.description = description;
    }
	
	// getters and setters
	//-----------------------------------------------------------------------
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        validateName(name);
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

	// local validation functions
	//-----------------------------------------------------------------------
    private void validateId(String id) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("Task ID must be non-null and at most 10 characters.");
        }
    }

    private void validateName(String nm) {
        if (nm == null || nm.length() > 20) {
            throw new IllegalArgumentException("Name must be non-null and at most 20 characters.");
        }
    }

    private void validateDescription(String desc) {
        if (desc == null || desc.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and at most 50 characters.");
        }
    }

    // Overrides
	//-----------------------------------------------------------------------
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Task)) return false;
        Task task = (Task) o;
        return Objects.equals(taskId, task.taskId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId);
    }

}
